﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization;
using System.Windows.Forms.DataVisualization.Charting;

namespace demo
{
    public partial class frmChart : Form
    {
        //Database 
        SqlConnection cn = new SqlConnection();
        DBConnection dbcon = new DBConnection();

        // Import CreateRoundRectRgn
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect,
            int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse
        );

        // Border color
        private Color borderColor = Color.FromArgb(158, 57, 128);
        private int borderRadius = 30;
        private int borderThickness = 2;

        public frmChart()
        {

            InitializeComponent();
            //Database 
            cn = new SqlConnection(dbcon.Myconnection());


            this.FormBorderStyle = FormBorderStyle.None;
            this.DoubleBuffered = true;
            this.BackColor = Color.White;

            // Set the rounded region
            this.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, borderRadius, borderRadius));

            // Optional: enable drag
            this.MouseDown += frmChart_MouseDown;
        }

        // Reapply region when resized
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            this.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, borderRadius, borderRadius));
            this.Invalidate(); // Repaint border
        }

        // Draw custom border
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            using (Pen pen = new Pen(borderColor, borderThickness))
            {
                pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Inset;

                Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
                Graphics g = e.Graphics;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawArc(pen, rect.X, rect.Y, borderRadius, borderRadius, 180, 90); // top-left
                g.DrawArc(pen, rect.Right - borderRadius, rect.Y, borderRadius, borderRadius, 270, 90); // top-right
                g.DrawArc(pen, rect.X, rect.Bottom - borderRadius, borderRadius, borderRadius, 90, 90); // bottom-left
                g.DrawArc(pen, rect.Right - borderRadius, rect.Bottom - borderRadius, borderRadius, borderRadius, 0, 90); // bottom-right
                g.DrawRectangle(pen, rect);
            }
        }

        // Optional: Dragging support
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImport("User32.dll")]
        public static extern bool ReleaseCapture();

        [DllImport("User32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        private void frmChart_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void LoadChartSold(string sql)
        {
            SqlDataAdapter da;
            cn.Open();
            da = new SqlDataAdapter(sql,cn);

            DataSet ds = new DataSet();
            da.Fill(ds, "SOLD");
            chart1.DataSource = ds.Tables["SOLD"];
            Series series = chart1.Series[0];
            series.ChartType = SeriesChartType.Doughnut;

            series.Name = "SOLD ITEMS";
            chart1.Series[0].XValueMember = "pdesc";
            chart1.Series[0].YValueMembers = "total";
            chart1.Series[0].LabelFormat = "{#,##0.00}";
            chart1.Series[0].IsValueShownAsLabel = true;
            cn.Close();

        }
    }
}

