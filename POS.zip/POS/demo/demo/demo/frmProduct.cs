﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;
using BarcodeStandard;
using System.Drawing.Imaging;

namespace demo
{
    public partial class frmProduct : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        frmProductList flist;
        public frmProduct(frmProductList frm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.Myconnection());
            flist = frm;
        }

        public void LoadCategory()
        {
            cboCategory.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT category FROM tblCategory",cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cboCategory.Items.Add(dr[0].ToString());
            }
            dr.Close();
            cn.Close();
        }

        public void LoadBrand()
        {
            cboBrand.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT brand FROM tblBrand", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cboBrand.Items.Add(dr[0].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            try
            {
                if(MessageBox.Show("Are you sure you want save this product?","Save Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string bid = ""; string cid = "";
                    cn.Open();
                    cm = new SqlCommand("SELECT id FROM tblBrand WHERE brand like '" + cboBrand.Text + "'", cn);
                    dr = cm.ExecuteReader();
                    dr.Read();
                    if (dr.HasRows){bid = dr[0].ToString();}
                    dr.Close() ;
                    cn.Close();

                    cn.Open() ;
                    cm = new SqlCommand("SELECT id FROM tblCategory WHERE category like '" + cboCategory.Text + "'", cn);
                    dr = cm.ExecuteReader();
                    dr.Read();
                    if (dr.HasRows) { cid = dr[0].ToString(); }
                    dr.Close();
                    cn.Close();

                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblProduct (pcode,barcode,pdesc,bid,cid,price,reorder)VALUES(@pcode,@barcode,@pdesc,@bid,@cid,@price,@reorder)", cn);
                    cm.Parameters.AddWithValue("@pcode",txtPcode.Text);
                    cm.Parameters.AddWithValue("@barcode",txtBarcode.Text);
                    cm.Parameters.AddWithValue("@pdesc", txtPdesc.Text);
                    cm.Parameters.AddWithValue("@bid", bid);
                    cm.Parameters.AddWithValue("@cid", cid);
                    cm.Parameters.AddWithValue("@price", double.Parse(txtPrice.Text));
                    cm.Parameters.AddWithValue("@reorder", int.Parse(txtReorder.Text));
                    cm.ExecuteNonQuery();
                    cn.Close() ;
                    MessageBox.Show("Product has been successfully Saved.");
                    Clear();
                    flist.LoadRecord();
                }
            }catch(Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        public void Clear()
        {
            txtPcode.Clear();
            txtBarcode.Clear();
            txtPdesc.Clear();
            txtPrice.Clear();
            cboBrand.Text = "";
            cboCategory.Text = "";
            txtPcode.Focus();
            btnSave.Enabled = true;
            btnUpdate.Enabled = false;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want update this product?", "Save Product", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    string bid = ""; string cid = "";
                    cn.Open();
                    cm = new SqlCommand("SELECT id FROM tblBrand WHERE brand like '" + cboBrand.Text + "'", cn);
                    dr = cm.ExecuteReader();
                    dr.Read();
                    if (dr.HasRows) { bid = dr[0].ToString(); }
                    dr.Close();
                    cn.Close();

                    cn.Open();
                    cm = new SqlCommand("SELECT id FROM tblCategory WHERE category like '" + cboCategory.Text + "'", cn);
                    dr = cm.ExecuteReader();
                    dr.Read();
                    if (dr.HasRows) { cid = dr[0].ToString(); }
                    dr.Close();
                    cn.Close();

                    cn.Open();
                    cm = new SqlCommand("UPDATE tblProduct SET barcode =@barcode, pdesc =@pdesc,bid=@bid,cid=@cid,price=@price,reorder=@reorder WHERE pcode like @pcode", cn);
                    cm.Parameters.AddWithValue("@pcode", txtPcode.Text);
                    cm.Parameters.AddWithValue("@barcode", txtBarcode.Text);
                    cm.Parameters.AddWithValue("@pdesc", txtPdesc.Text);
                    cm.Parameters.AddWithValue("@bid", bid);
                    cm.Parameters.AddWithValue("@cid", cid);
                    cm.Parameters.AddWithValue("@price", double.Parse(txtPrice.Text));
                    cm.Parameters.AddWithValue("@reorder", int.Parse(txtReorder.Text));
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Product has been successfully Updated.");
                    Clear();
                    flist.LoadRecord();
                    Close();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (e.KeyChar == 46)
            //{
            //    //accepted character
            //} else if (e.KeyChar == 8) { 
            //    //accepted backsspace
            //}else if ((e.KeyChar < 48) || (e.KeyChar < 57))
            //{
            //    e.Handled = true;
            //}
            if (char.IsControl(e.KeyChar))
            {
                return;
            }

            // Allow only digits and one dot
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }

            // Allow only one dot
            if (e.KeyChar == '.' && (sender as TextBox).Text.Contains("."))
            {
                e.Handled = true;
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //string pcode = "2025" + new Random().Next(10000, 99999).ToString();
            //txtPcode.Text = pcode;

            //Barcode barcode = new Barcode();
            //Image img = barcode.Encode(TYPE.CODE128, pcode, Color.Black, Color.White, 300, 100);
            //pictureBoxBarcode.Image = img;
            string newBarcode = "";
            cn.Open();

            SqlCommand cm = new SqlCommand("SELECT MAX(CAST(barcode AS INT)) AS LastBarcode FROM tblProduct", cn);
            SqlDataReader dr = cm.ExecuteReader();

            if (dr.Read() && dr["LastBarcode"] != DBNull.Value)
            {
                int lastBarcode = Convert.ToInt32(dr["LastBarcode"]); // e.g., 2005
                int nextBarcode = lastBarcode + 1;
                newBarcode = nextBarcode.ToString(); // e.g., "2006"
            }
            else
            {
                newBarcode = "2001"; // Start if no barcode yet
            }

            dr.Close();
            cn.Close();

            // Assign to textbox
            txtBarcode.Text = newBarcode;

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string newProductCode = "";
            cn.Open();
            SqlCommand cm = new SqlCommand("SELECT TOP 1 pcode FROM tblProduct ORDER BY pcode DESC", cn);
            SqlDataReader dr = cm.ExecuteReader();

            if (dr.Read())
            {
                string lastCode = dr["pcode"].ToString(); // e.g., "P012"
                int lastNumber = int.Parse(lastCode.Substring(1)); // Remove 'P' and convert to int
                int nextNumber = lastNumber + 1;
                newProductCode = "P" + nextNumber.ToString("D3"); // Format as P001, P002, etc.
            }
            else
            {
                // No products yet, start from P001
                newProductCode = "P001";
            }

            dr.Close();
            cn.Close();

            txtPcode.Text = newProductCode;


        }

        private void frmProduct_Load(object sender, EventArgs e)
        {

        }

        private void cboBrand_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtBarcode_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPdesc_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPcode_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtReorder_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
