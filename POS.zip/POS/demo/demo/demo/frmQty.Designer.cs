﻿namespace demo
{
    partial class frmQty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtQty = new System.Windows.Forms.TextBox();
            this.btnSubmitQty = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtQty
            // 
            this.txtQty.BackColor = System.Drawing.SystemColors.Info;
            this.txtQty.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtQty.Font = new System.Drawing.Font("Consolas", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQty.Location = new System.Drawing.Point(0, 0);
            this.txtQty.Multiline = true;
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(257, 119);
            this.txtQty.TabIndex = 0;
            this.txtQty.Text = "1";
            this.txtQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQty.TextChanged += new System.EventHandler(this.txtQty_TextChanged);
            // 
            // btnSubmitQty
            // 
            this.btnSubmitQty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(38)))));
            this.btnSubmitQty.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnSubmitQty.FlatAppearance.BorderSize = 0;
            this.btnSubmitQty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSubmitQty.Font = new System.Drawing.Font("Yu Gothic UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmitQty.ForeColor = System.Drawing.Color.White;
            this.btnSubmitQty.Location = new System.Drawing.Point(0, 78);
            this.btnSubmitQty.Name = "btnSubmitQty";
            this.btnSubmitQty.Size = new System.Drawing.Size(257, 41);
            this.btnSubmitQty.TabIndex = 5;
            this.btnSubmitQty.Text = "SAVE";
            this.btnSubmitQty.UseVisualStyleBackColor = false;
            this.btnSubmitQty.Click += new System.EventHandler(this.btnSubmitQty_Click);
            // 
            // frmQty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(257, 119);
            this.Controls.Add(this.btnSubmitQty);
            this.Controls.Add(this.txtQty);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmQty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUANTITY";
            this.Load += new System.EventHandler(this.frmQty_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmQty_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtQty;
        public System.Windows.Forms.Button btnSubmitQty;
    }
}