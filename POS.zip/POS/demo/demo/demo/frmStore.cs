﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace demo
{
    public partial class frmStore : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataReader dr;
        DBConnection db = new DBConnection();
        public frmStore()
        {
            InitializeComponent();
            cn = new SqlConnection(db.Myconnection());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }
        public void LoadRecord()
        {
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblStore",cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                txtStore.Text = dr["store"].ToString();
                txtAddress.Text = dr["address"].ToString();
            }
            else
            {
                txtStore.Clear();
                txtAddress.Clear();
            }
            dr.Close();
            cn.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //    try
            //    {
            //        if (MessageBox.Show("Are you sure you want to save to store?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            //        {
            //            int count;
            //            cn.Open();
            //            cm = new SqlCommand("SELECT count(*) FROM tblStore", cn);
            //            count = int.Parse(cm.ExecuteScalar().ToString());
            //            cn.Close();

            //            if(count > 0)
            //            {
            //                cn.Open();
            //                cm =new SqlCommand("UPDATE tblStore SET store=@store,address=@address",cn);
            //                cm.Parameters.AddWithValue("@store", txtStore.Text);
            //                cm.Parameters.AddWithValue("@address",txtAddress.Text);
            //                cm.ExecuteNonQuery();
            //            }else
            //            {
            //                cn.Open();
            //                cm = new SqlCommand("INSERT INTO tblStore(store,address)VALUES(@store,@address)", cn);
            //                cm.Parameters.AddWithValue("@store",txtStore.Text );
            //                cm.Parameters.AddWithValue("@address",txtAddress.Text);
            //                cm.ExecuteNonQuery(); 
            //            }
            //            MessageBox.Show("Store Has been successfully saved.", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        cn.Close();
            //        MessageBox.Show(ex.Message);
            //    }
            try
            {
                if (MessageBox.Show("Are you sure you want to save to store?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    int count;
                    cn.Open();
                    cm = new SqlCommand("SELECT COUNT(*) FROM tblStore", cn);
                    count = Convert.ToInt32(cm.ExecuteScalar());
                    cn.Close();

                    cn.Open();
                    if (count > 0)
                    {
                        cm = new SqlCommand("UPDATE tblStore SET store=@store, address=@address", cn);
                    }
                    else
                    {
                        cm = new SqlCommand("INSERT INTO tblStore(store, address) VALUES(@store, @address)", cn);
                    }

                    cm.Parameters.AddWithValue("@store", txtStore.Text);
                    cm.Parameters.AddWithValue("@address", txtAddress.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();

                    MessageBox.Show("Store has been successfully saved.", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
                MessageBox.Show(ex.Message);
            }

        }


    }
}
