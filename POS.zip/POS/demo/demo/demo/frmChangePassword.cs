﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace demo
{
    public partial class frmChangePassword : Form
    {
        SqlConnection cn;
        SqlCommand cm;
        DBConnection db= new DBConnection();
        frmPOS f;
        public frmChangePassword(frmPOS frm)
        {
            InitializeComponent();
            cn = new SqlConnection(db.Myconnection());
            f = frm;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void frmChangePassword_Load(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string _oldPass =db.GetPassword(f.lblUser.Text);
                if (_oldPass != txtOld.Text)
                {
                    MessageBox.Show("Old Password did not matched!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }else if (txtNew.Text != txtConfirm.Text)
                {
                    MessageBox.Show("Confirm New Password did not matched!", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if(MessageBox.Show("Change the Passwrod?", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("UPDATE tblUser SET password = @password WHERE username = @username",cn);
                        cm.Parameters.AddWithValue("password",txtNew.Text);
                        cm.Parameters.AddWithValue("username", f.lblUser.Text);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        MessageBox.Show("Password Changed Sucessfully!", "SUCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Close();
                    }
                }
            }catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message,"ERROR",MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
