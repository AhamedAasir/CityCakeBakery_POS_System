﻿namespace demo
{


    partial class DataSet1
    {
        partial class dtStockInDataTable
        {
        }

        partial class dtSoldItemsDataTable
        {
        }

        partial class dtSoldReportDataTable
        {
        }
    }
}
