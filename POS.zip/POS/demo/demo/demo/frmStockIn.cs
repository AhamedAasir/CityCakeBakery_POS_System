﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo
{
    public partial class frmStockIn : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        string sttilte = "Simple pos system";
        public frmStockIn()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.Myconnection());
            LoadVendor();
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
                

        }


        public void LoadStockIn()
        {
            int i = 0;
            dataGridView2.Rows.Clear();

            cn.Open();
            cm = new SqlCommand("SELECT * FROM vwStockin WHERE refno like '" + txtRefNo.Text + "' and status like 'pending'", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView2.Rows.Add(i, dr[0].ToString(),dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr["vendor"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void LoadStockInHistory()
        {
            int i = 0;
            dataGridView1.Rows.Clear();

            cn.Open();
            cm = new SqlCommand("SELECT * FROM vwStockin WHERE cast(sdate as date) between'" + date1.Value.ToShortDateString() + "'and'" + date2.Value.ToShortDateString() + "'and status like 'Done'", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(),DateTime.Parse(dr[5].ToString()).ToShortDateString(), dr[6].ToString(), dr["vendor"].ToString());
            }
            dr.Close();
            cn.Close();
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }
        public void Clear()
        {
            txtBy.Clear();
            txtRefNo.Clear();
            dt1.Value= DateTime.Now;
        }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (colName == "colDelete")
            {
                if (MessageBox.Show("Remove this item?", sttilte, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("DELETE FROM tblStockIn WHERE id LIKE '" + dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Successfully deleted", sttilte, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadStockIn();
                }
               
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSearchProduct_Stockin frm = new frmSearchProduct_Stockin(this);
            frm.LoadProduct();
            frm.ShowDialog();

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView2.Rows.Count > 0)
                {
                    if (MessageBox.Show("Are you sure you want to save this product?", sttilte, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {


                        for (int i = 0; i < dataGridView2.Rows.Count; i++)
                        {
                            //update tblproduct qty
                            cn.Open();
                            cm = new SqlCommand("UPDATE  tblProduct SET qty = qty + " + int.Parse(dataGridView2.Rows[i].Cells[5].Value.ToString()) + "WHERE pcode like '" + dataGridView2.Rows[i].Cells[3].Value.ToString() + "'", cn);
                            cm.ExecuteNonQuery();
                            cn.Close();

                            //update tblstockin qty
                            cn.Open();
                            cm = new SqlCommand("UPDATE tblStockin SET qty = qty + " + int.Parse(dataGridView2.Rows[i].Cells[5].Value.ToString()) + ",status = 'Done' WHERE id like '" + dataGridView2.Rows[i].Cells[1].Value.ToString() + "'", cn);
                            cm.ExecuteNonQuery();
                            cn.Close();
                        }
                        Clear();
                        LoadStockIn();
                    }
                }
            }catch(Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, sttilte, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadStockInHistory();
        }

        public void LoadVendor()
        {
            cmbVendor.Items.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT vendor FROM tblVendor", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                cmbVendor.Items.Add(dr[0].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void cmbVendor_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void cmbVendor_TextChanged(object sender, EventArgs e)
        {
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tblVendor WHERE vendor like '" + cmbVendor.Text + "'", cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                lblVendorID.Text= dr["id"].ToString();
                txtVendorContact.Text = dr["contactperson"].ToString();
                txtVendorAddress.Text = dr["address"].ToString();
            }
            dr.Close();
            cn.Close();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Random rn = new Random();
            txtRefNo.Clear();
            int i = 0;
            for (i=0;i < 10; i++)
            {
                txtRefNo.Text += rn.Next(0, 9).ToString();
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
