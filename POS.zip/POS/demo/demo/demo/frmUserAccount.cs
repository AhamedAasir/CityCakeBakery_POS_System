﻿using Microsoft.ReportingServices.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo
{
    public partial class frmUserAccount : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        Form1 f;
        SqlDataReader dr;
        public frmUserAccount(Form1 f)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.Myconnection());
            this.f = f;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmUserAccount_Resize(object sender, EventArgs e)
        {
            metroTabControl1.Left = (this.Width - metroTabControl1.Width) / 2;
            metroTabControl1.Top = (this.Height - metroTabControl1.Height) / 2;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtPass.Text != txtRetype.Text)
                {
                    MessageBox.Show("Password Did not matched", "Enter Correctly", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                cn.Open();
                cm = new SqlCommand("INSERT INTO tblUser (username,password,role,name)VALUES(@username,@password,@role,@name)", cn);
                cm.Parameters.AddWithValue("@username", txtUser.Text);
                cm.Parameters.AddWithValue("@password", txtPass.Text);
                cm.Parameters.AddWithValue("@role", cboRole.Text);
                cm.Parameters.AddWithValue("@name", txtName.Text);

                cm.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("User Account has been successfully Created.");
                Clear();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }
        public void Clear()
        {
            txtUser.Clear();
            txtPass.Clear();
            txtRetype.Clear();
            txtName.Clear();
            cboRole.Text = "";
            txtUser.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtOld1.Text != f._pass)
                {
                    MessageBox.Show("Old Password Did not matched!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                if (txtNew1.Text != txtRetype1.Text)
                {
                    MessageBox.Show("Confirm New Password Did not matched!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                cn.Open();
                cm = new SqlCommand("UPDATE tblUser SET  password=@password WHERE username=@username", cn);
                cm.Parameters.AddWithValue("@password", txtNew1.Text);
                cm.Parameters.AddWithValue("@username", txtUser1.Text);
                cm.ExecuteNonQuery();

                cn.Close();
                MessageBox.Show("Password Has been Succesfully Changed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //txtUser1.Clear();
                txtOld1.Clear();
                txtRetype1.Clear();
                txtNew1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                cn.Open();
                cm = new SqlCommand("SELECT * FROM tblUser WHERE username=@username", cn);
                cm.Parameters.AddWithValue("@username", txtUser2.Text);
                dr = cm.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    checkBox1.Checked = bool.Parse(dr["isactive"].ToString());
                }
                else
                {
                    checkBox1.Checked = false;
                }
                dr.Close();
                cn.Close();

            } catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, "warnning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                bool found = true;

                  cn.Open();
                    cm = new SqlCommand("SELECT * FROM tblUser WHERE username=@username", cn);
                    cm.Parameters.AddWithValue("@username", txtUser2.Text);
                    dr = cm.ExecuteReader();
                    dr.Read();
                    if (dr.HasRows) { found = true; } else { found = false; }

                    dr.Close();
                    cn.Close();
              
                    if (found == true)
                    {
                        cn.Open();
                        cm = new SqlCommand("UPDATE tblUser SET isactive=@isactive WHERE username = @username", cn);
                        cm.Parameters.AddWithValue("@isactive", checkBox1.Checked.ToString());
                        cm.Parameters.AddWithValue("@username", txtUser2.Text);
                        cm.ExecuteNonQuery();
                        cn.Close();
                    MessageBox.Show("Account has been Successfully Activated!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtUser2.Clear();
                    checkBox1.Checked = false;
                }
                else
                {
                    MessageBox.Show("Account Not exists!", "warnning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                }
                catch (Exception ex)
                {
                    cn.Close();
                    MessageBox.Show(ex.Message, "warnning", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
    }
    } 
