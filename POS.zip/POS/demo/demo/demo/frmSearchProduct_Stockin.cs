﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace demo
{
    public partial class frmSearchProduct_Stockin : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        string sttilte = "Simple pos system";
        frmStockIn slist;
        public frmSearchProduct_Stockin(frmStockIn flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.Myconnection());
            slist = flist;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }
        public void LoadProduct()
        {
            int i = 0;
            dataGridView1.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT pcode,pdesc,qty FROM tblProduct WHERE pdesc like'%" + txtSearch.Text + "%'order by pdesc", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string colName = dataGridView1.Columns[e.ColumnIndex].Name;
                if (colName == "colSelect")
                {
                    if (slist.txtRefNo.Text == string.Empty) { MessageBox.Show("Please enter reference no", sttilte, MessageBoxButtons.OK, MessageBoxIcon.Warning); slist.txtRefNo.Focus(); return; }
                    if (slist.txtBy.Text == string.Empty) { MessageBox.Show("Please enter stock in by", sttilte, MessageBoxButtons.OK, MessageBoxIcon.Warning); slist.txtBy.Focus(); return; }
                    if (MessageBox.Show("Add this item?", sttilte, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();

                        cm = new SqlCommand("INSERT INTO tblStockIn (refno, pcode, sdate, stockinby,vendorid) VALUES (@refno, @pcode, @sdate, @stockinby,@vendorid)", cn);
                        cm.Parameters.Add("@refno", SqlDbType.VarChar).Value = slist.txtRefNo.Text;
                        cm.Parameters.Add("@pcode", SqlDbType.VarChar).Value = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                        cm.Parameters.Add("@sdate", SqlDbType.DateTime).Value = slist.dt1.Value;
                        cm.Parameters.Add("@stockinby", SqlDbType.VarChar).Value = slist.txtBy.Text;
                        cm.Parameters.Add("@vendorid", SqlDbType.Int).Value = slist.lblVendorID.Text;

                        cm.ExecuteNonQuery();

                        cn.Close();
                        MessageBox.Show("Successfully Added", sttilte, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        slist.LoadStockIn();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred during insertion: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadProduct();
        }
    }
}
