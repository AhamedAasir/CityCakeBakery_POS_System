﻿using SkiaSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace demo
{
    public partial class frmRecords : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        public frmRecords()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.Myconnection());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void LoadRecord()
        {
            //int i = 0;
            //cn.Open();
            //cm = new SqlCommand("SELECT TOP 10 pcode,pdesc,sum(qty) AS qty FROM vwSoldItems WHERE sdate BETWEEN '" + dateTimePicker1.Value.ToString() + "'AND '" + dateTimePicker2.Value.ToString() +"' AND status LIKE 'Sold' GROUP BY pcode,pdesc ORDER BY qty desc",cn);
            //dr = cm.ExecuteReader();
            //while(dr.Read())
            //{
            //    i+=1;
            //    dataGridView1.Rows.Add(i,dr["pcode"].ToString(), dr["pdesc"].ToString(), dr["qty"].ToString());
            //}
            //dr.Close();
            //cn.Close();
            dataGridView1.Rows.Clear();
            int i = 0;
            cn.Open();

            if (cboTopSelect.Text == "SORT BY QTY")
            {
                cm = new SqlCommand(@"SELECT TOP 10 pcode, pdesc, isnull(SUM(qty),0) AS qty, isnull(SUM(total),0) AS total 
                      FROM vwSoldItems 
                      WHERE CONVERT(date, sdate) BETWEEN @start AND @end 
                      AND status = 'Sold' 
                      GROUP BY pcode, pdesc 
                      ORDER BY qty DESC", cn);
                // Use only the Date part to avoid time mismatches
                cm.Parameters.AddWithValue("@start", dateTimePicker1.Value.Date);
                cm.Parameters.AddWithValue("@end", dateTimePicker2.Value.Date);
            }
            else if (cboTopSelect.Text == "SORT BY TOTAL AMOUNT")
            {
                cm = new SqlCommand(@"SELECT TOP 10 pcode, pdesc, isnull(SUM(qty),0) AS qty, isnull(SUM(total),0) AS total 
                      FROM vwSoldItems 
                      WHERE CONVERT(date, sdate) BETWEEN @start AND @end 
                      AND status = 'Sold' 
                      GROUP BY pcode, pdesc 
                      ORDER BY total DESC", cn);
                // Use only the Date part to avoid time mismatches
                cm.Parameters.AddWithValue("@start", dateTimePicker1.Value.Date);
                cm.Parameters.AddWithValue("@end", dateTimePicker2.Value.Date);
            }

            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i += 1;
                dataGridView1.Rows.Add(i, dr["pcode"].ToString(), dr["pdesc"].ToString(), dr["qty"].ToString(),double.Parse(dr["total"].ToString()));
            }
            dr.Close();
            cn.Close();

        }
        public void CancelOrders()
        {
            int i = 0;
            dataGridView5.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM vwCancelledOrder WHERE sdate BETWEEN '" + dateTimePicker5.Value.ToString() + "' and '" + dateTimePicker6.Value.ToString() + "'",cn);
            dr=cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView5.Rows.Add(i, dr["transno"].ToString(), dr["pcode"].ToString(), dr["pdesc"].ToString(), dr["price"].ToString(), dr["qty"].ToString(), dr["total"].ToString(), dr["sdate"].ToString(), dr["voidby"].ToString(), dr["cancelledby"].ToString(), dr["reason"].ToString(), dr["action"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        public void LoadInventory()
        {
            int i = 0;
            dataGridView4.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT p.pcode,p.barcode,p.pdesc,b.brand,c.category,p.price,p.qty,p.reorder FROM tblProduct as p INNER JOIN tblBrand as b ON p.bid = b.id INNER JOIN tblCategory as c ON p.cid = c.id",cn);
            dr=cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView4.Rows.Add(i, dr["pcode"].ToString(), dr["barcode"].ToString(), dr["pdesc"].ToString(), dr["brand"].ToString(), dr["category"].ToString(), double.Parse(dr["price"].ToString()).ToString("n2"), int.Parse(dr["qty"].ToString()), int.Parse(dr["reorder"].ToString()));

            }
            dr.Close();
            cn.Close();
        }

        public void LoadCriticalItems()
        {
            try
            {
                int i = 0;
                dataGridView3.Rows.Clear();
                cn.Open();
                cm = new SqlCommand("SELECT * FROM vwCriticalItems",cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    i++;
                    dataGridView3.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString());
                }
                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmInventoryReport frm = new frmInventoryReport();
            frm.LoadReport();
            frm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        public void LoadStockInHistory()
        {
            int i = 0;
            dataGridView6.Rows.Clear();

            cn.Open();
            cm = new SqlCommand("SELECT * FROM vwStockin WHERE cast(sdate as date) between'" + date1.Value.ToShortDateString() + "'and'" + date2.Value.ToShortDateString() + "'and status like 'Done'", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView6.Rows.Add(i, dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), DateTime.Parse(dr[5].ToString()).ToShortDateString(), dr[6].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void linkLabel6_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmInventoryReport f = new frmInventoryReport();
            if (cboTopSelect.Text == "SORT BY QTY")
            {
             f.LoadTopSelling("SELECT TOP 10 pcode,pdesc,isnull(sum(qty),0) as qty,isnull(sum(total),0) as total from vwSoldItems where sdate BETWEEN '" + dateTimePicker1.Value.ToString() + "'AND '" + dateTimePicker2.Value.ToString() + "' AND status LIKE 'Sold' GROUP BY pcode,pdesc ORDER BY qty desc", "From :" + dateTimePicker1.Value.ToString() + "To :" + dateTimePicker2.Value.ToString(),"TOP SELLING ITEMS SORT BY QTY");
            }
            else if (cboTopSelect.Text == "SORT BY TOTAL AMOUNT")
            {
             f.LoadTopSelling("SELECT TOP 10 pcode,pdesc,isnull(sum(qty),0) as qty,isnull(sum(total),0) as total from vwSoldItems where sdate between '" + dateTimePicker1.Value.ToString() + "'AND '" + dateTimePicker2.Value.ToString() + "' AND status LIKE 'Sold' GROUP BY pcode,pdesc ORDER BY total desc", "From :" + dateTimePicker1.Value.ToString() + "To :" + dateTimePicker2.Value.ToString(),"TOP SELLING ITEMS SORT BY TOTAL AMOUNT");
            }
            

            //f.LoadTopSelling(@"SELECT TOP 10 pcode, pdesc, SUM(qty) AS qty FROM vwSoldItems WHERE CONVERT(date, sdate) BETWEEN @start AND @end AND status = 'Sold' GROUP BY pcode, pdesc ORDER BY qty DESC");

            //cm.Parameters.AddWithValue("@start", dateTimePicker1.Value.Date);
            //cm.Parameters.AddWithValue("@end", dateTimePicker2.Value.Date);
            
            f.ShowDialog();
           
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmInventoryReport f= new frmInventoryReport();
            f.LoadSoldItems("SELECT c.pcode,p.pdesc,c.price,sum(c.qty) as Total_QTY,sum(c.disc) as Totoal_Discount,sum(c.total) as Total FROM tblCart AS c INNER JOIN tblProduct AS p ON c.pcode = p.pcode WHERE status LIKE 'Sold' AND sdate BETWEEN '" + dateTimePicker4.Value.ToString() + "'AND '" + dateTimePicker3.Value.ToString() + "'group by c.pcode,p.pdesc,c.price","From :" + dateTimePicker4.Value.ToString() + "To :" + dateTimePicker3.Value.ToString());
            f.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void linkLabel7_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (cboTopSelect.Text == string.Empty)
            {
                MessageBox.Show("PLEASE SELECT THE DROPDOWN LIST SORT ITEM.", "WARINING", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            LoadRecord();
            LoadChartTopSelling();
        }
        public void LoadChartTopSelling()
        {

            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter();

            if (cboTopSelect.Text == "SORT BY QTY")
            {
                da = new SqlDataAdapter(@"SELECT TOP 10 pcode, ISNULL(SUM(qty), 0) AS qty 
                              FROM vwSoldItems 
                              WHERE CONVERT(date, sdate) BETWEEN @start AND @end 
                              AND status = 'Sold' 
                              GROUP BY pcode 
                              ORDER BY qty DESC", cn);
            }
            else if (cboTopSelect.Text == "SORT BY TOTAL AMOUNT")
            {
                da = new SqlDataAdapter(@"SELECT TOP 10 pcode, ISNULL(SUM(total), 0) AS total 
                              FROM vwSoldItems 
                              WHERE CONVERT(date, sdate) BETWEEN @start AND @end 
                              AND status = 'Sold' 
                              GROUP BY pcode 
                              ORDER BY total DESC", cn);
            }

            // ✅ Add parameters to the adapter's SelectCommand
            da.SelectCommand.Parameters.AddWithValue("@start", dateTimePicker1.Value.Date);
            da.SelectCommand.Parameters.AddWithValue("@end", dateTimePicker2.Value.Date);
            



            DataSet ds = new DataSet();
            da.Fill(ds, "TOPSELLING");
            chart1.DataSource = ds.Tables["TOPSELLING"];
            Series series = chart1.Series[0];
            series.ChartType = SeriesChartType.Doughnut;

            series.Name = "TOP SELLING";
            var chart = chart1;
            chart.Series[0].XValueMember="pcode";

            if (cboTopSelect.Text == "SORT BY QTY") { chart.Series[0].YValueMembers = "qty"; }
            if (cboTopSelect.Text == "SORT BY TOTAL AMOUNT") { chart.Series[0].YValueMembers = "total"; }
            chart.Series[0].IsValueShownAsLabel = true;
            if (cboTopSelect.Text == "SORT BY TOTAL AMOUNT") { chart.Series[0].LabelFormat = "{#,#0.00}"; }
            if (cboTopSelect.Text == "SORT BY QTY") { chart.Series[0].LabelFormat = "{#,#0}"; }
            cn.Close();
        }
        private void cboTopSelect_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true; 
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                dataGridView2.Rows.Clear();
                int i = 0;
                cn.Open();
                cm = new SqlCommand("SELECT c.pcode,p.pdesc,c.price,sum(c.qty) as Total_QTY,sum(c.disc) as Totoal_Discount,sum(c.total) as Total FROM tblCart AS c INNER JOIN tblProduct AS p ON c.pcode = p.pcode WHERE status LIKE 'Sold' AND sdate BETWEEN '" + dateTimePicker4.Value.ToString() + "'AND '" + dateTimePicker3.Value.ToString() + "'group by c.pcode,p.pdesc,c.price", cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    i += 1;
                    dataGridView2.Rows.Add(i, dr["pcode"].ToString(), dr["pdesc"].ToString(), double.Parse(dr["price"].ToString()).ToString("n2"), dr["Total_QTY"].ToString(), dr["Totoal_Discount"].ToString(), double.Parse(dr["Total"].ToString()).ToString("n2"));
                }
                dr.Close();
                cn.Close();

                cn.Open();
                cm = new SqlCommand("SELECT isnull(sum(total),0) FROM tblCart WHERE status LIKE 'Sold' AND sdate BETWEEN '" + dateTimePicker4.Value.ToString() + "'AND '" + dateTimePicker3.Value.ToString() + "'", cn);
                lblTotal.Text = double.Parse(cm.ExecuteScalar().ToString()).ToString("n2");
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CancelOrders();
        }

        private void linkLabel11_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LoadStockInHistory();
        }

        private void linkLabel10_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmChart f = new frmChart();
            f.lblTitle.Text = "SOLD ITEMS [" + dateTimePicker4.Value.ToShortDateString() + " - " + dateTimePicker3.Value.ToShortDateString() + "]";
            f.LoadChartSold("SELECT p.pdesc,sum(c.total) as Total FROM tblCart AS c INNER JOIN tblProduct AS p ON c.pcode = p.pcode WHERE status LIKE 'Sold' AND sdate BETWEEN '" + dateTimePicker4.Value.ToString() + "'AND '" + dateTimePicker3.Value.ToString() + "'group by p.pdesc order by total desc");
            f.ShowDialog();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmInventoryReport frm = new frmInventoryReport();
            string param = "Date Covered:" + date1.Value.ToShortDateString() + " - " + date2.Value.ToShortDateString();
            frm.LoadStockInReport("SELECT * FROM vwStockin WHERE cast(sdate as date) between'" + date1.Value.ToShortDateString() + "'and'" + date2.Value.ToShortDateString() + "'and status like 'Done'",param);
            frm.ShowDialog();
            //
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmInventoryReport frm =new frmInventoryReport();
            string param = "Date Covered:" + dateTimePicker5.Value.ToString() + " - " + dateTimePicker6.Value.ToString();
            frm.LoadCancelOrder("SELECT * FROM vwCancelledOrder WHERE sdate BETWEEN '" + dateTimePicker5.Value.ToString() + "' and '" + dateTimePicker6.Value.ToString() + "'",param);
            frm.ShowDialog();
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
