﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Forms;

namespace demo
{
    public partial class frmSecurity : Form
    {
        //styling

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn(
            int nLeftRect, int nTopRect,
            int nRightRect, int nBottomRect,
            int nWidthEllipse, int nHeightEllipse);

        //styling
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        public string _pass, _username = "";
        public bool isactive=false;

        //border color
        private Color borderColor = Color.FromArgb(40, 167, 69);
        private int borderRadius = 30;
        private int borderThickness = 2;
        public frmSecurity()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.Myconnection());

            this.FormBorderStyle = FormBorderStyle.None;
            this.DoubleBuffered = true;
            this.BackColor = Color.White;

            // Set the rounded region
            this.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, borderRadius, borderRadius));

           
        }

        // Reapply region when resized
        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            this.Region = Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, borderRadius, borderRadius));
            this.Invalidate(); // Repaint border
        }

        // Draw custom border
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            using (Pen pen = new Pen(borderColor, borderThickness))
            {
                pen.Alignment = System.Drawing.Drawing2D.PenAlignment.Inset;

                Rectangle rect = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
                Graphics g = e.Graphics;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.DrawArc(pen, rect.X, rect.Y, borderRadius, borderRadius, 180, 90); // top-left
                g.DrawArc(pen, rect.Right - borderRadius, rect.Y, borderRadius, borderRadius, 270, 90); // top-right
                g.DrawArc(pen, rect.X, rect.Bottom - borderRadius, borderRadius, borderRadius, 90, 90); // bottom-left
                g.DrawArc(pen, rect.Right - borderRadius, rect.Bottom - borderRadius, borderRadius, borderRadius, 0, 90); // bottom-right
                g.DrawRectangle(pen, rect);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //txtUser.Clear();
            //txtPass.Clear();
            if(MessageBox.Show("EXIT Application!", "EXIT", MessageBoxButtons.YesNo, MessageBoxIcon.Question)== DialogResult.Yes)
            {
            Application.Exit();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            
            string  _role = "", _name = "";
            try
            {
                // 1. Both username and password are empty
                if (string.IsNullOrWhiteSpace(txtUser.Text) && string.IsNullOrWhiteSpace(txtPass.Text))
                {
                    MessageBox.Show("Please enter both username and password.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 2. Only username is empty
                if (string.IsNullOrWhiteSpace(txtUser.Text))
                {
                    MessageBox.Show("Please enter the username.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 3. Only password is empty
                if (string.IsNullOrWhiteSpace(txtPass.Text))
                {
                    MessageBox.Show("Please enter the password.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                bool found = false;
                cn.Open();
                cm = new SqlCommand("SELECT * FROM tblUser WHERE username=@username AND password=@password", cn);
                cm.Parameters.AddWithValue("@username", txtUser.Text);
                cm.Parameters.AddWithValue("@password", txtPass.Text);
                dr = cm.ExecuteReader();

                if (dr.Read()) // 7. Username & password both correct
                {
                    found = true;
                    _username = dr["username"].ToString();
                    _role = dr["role"].ToString();
                    _name = dr["name"].ToString();
                    _pass = dr["password"].ToString();
                    isactive = bool.Parse(dr["isactive"].ToString());
                }
                dr.Close();
                cn.Close();

                //if (found==true)
                //{
                //    MetroFramework.MetroMessageBox.Show(this,
                //    $"✅ Welcome, {_name}!\n\nYou have successfully logged in.",
                //    "✔ ACCESS GRANTED",
                //    MessageBoxButtons.OK,
                //    MessageBoxIcon.Information);
                //    txtUser.Clear();
                //    txtPass.Clear();
                //    this.Hide();

                //    if (isactive == false)
                //    {
                //        MessageBox.Show("Account is deactivate unable to login", "InActive Account", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //        return;
                //    }
                //    if (_role == "Casheir")
                //    {
                //        frmPOS frm = new frmPOS(this);
                //        frm.lblUser.Text = _username;
                //        frm.lblName.Text = _name + " | " + _role;
                //        frm.ShowDialog();
                //    }
                //    else
                //    {
                //        Form1 frm = new Form1();
                //        frm.lblname.Text = _name;
                //        frm.lblRole.Text = _role;
                //        frm._pass = _pass;
                //        frm._user= _username;
                //        frm.ShowDialog();
                //    }
                //}
                if (found == true)
                {
                    if (isactive == false)
                    {
                        MetroFramework.MetroMessageBox.Show(this,
                        "⛔ Your account is deactivated.\n\nPlease contact the administrator.",
                        "Inactive Account",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error);
                        return;
                    }

                    MetroFramework.MetroMessageBox.Show(this,
                    $"✅ Welcome, {_name}!\n\nYou have successfully logged in.",
                    "✔ ACCESS GRANTED",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                    txtUser.Clear();
                    txtPass.Clear();
                    this.Hide();

                    if (_role == "Casheir")
                    {
                        frmPOS frm = new frmPOS(this);
                        frm.lblUser.Text = _username;
                        frm.lblName.Text = _name + " | " + _role;
                        frm.ShowDialog();
                    }
                    else
                    {
                        Form1 frm = new Form1();
                        frm.lblname.Text = _name;
                        frm.lblRole.Text = _role;
                        frm._pass = _pass;
                        frm._user = _username;
                        frm.ShowDialog();
                    }
                }

                else
                {
                    // Now check further to guide the user more specifically:
                    cn.Open();
                    // 4. Username correct, password wrong
                    cm = new SqlCommand("SELECT * FROM tblUser WHERE username=@username", cn);
                    cm.Parameters.AddWithValue("@username", txtUser.Text);
                    dr = cm.ExecuteReader();

                    if (dr.HasRows)
                    {
                        dr.Close();
                        cn.Close();
                        //MessageBox.Show("Incorrect password.", "ACCESS DENIED", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        MetroFramework.MetroMessageBox.Show(this,
                        "❌ Incorrect password.\n\nAccess has been denied. Please try again.",
                        "⛔ ACCESS DENIED",
                         MessageBoxButtons.OK,
                         MessageBoxIcon.Warning);

                    }
                    else
                    {
                        dr.Close();
                        cn.Close();
                        // 5 & 6. Password correct, username wrong / both wrong
                        //MessageBox.Show("Invalid username.", "ACCESS DENIED", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        MetroFramework.MetroMessageBox.Show(this,
                        "🚫 Invalid username.\n\nPlease check and try again.",
                        "⛔ ACCESS DENIED",
                         MessageBoxButtons.OK,
                         MessageBoxIcon.Warning);

                    }
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void frmSecurity_KeyDown(object sender, KeyEventArgs e)
        {
            //if (e.KeyCode == Keys.Enter)
            //{
            //    txtPass_Click(sender, e);
            //}
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtPass_Click(object sender, EventArgs e)
        {

        }
    }
}
