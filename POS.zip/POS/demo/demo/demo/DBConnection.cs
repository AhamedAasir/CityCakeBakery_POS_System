﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Drawing.Imaging;
using System.Drawing.Printing;

namespace demo
{
    public class DBConnection
       
    {
        //SqlConnection cn = new SqlConnection();
        //SqlCommand cm = new SqlCommand();
        //DBConnection dbcon = new DBConnection();
        //SqlDataReader dr;
        private double dailysales;
        private int productline;
        private int stockonhand;
        private int critical;
        public string Myconnection()
        {
            
            //string con = @"Data Source=AASIR-2001;Initial Catalog=POS_DEMO_DB;Integrated Security=True;Trust Server Certificate=True";
            string con = @"Data Source=AASIR-2001;Initial Catalog=POS_DEMO_DB;Integrated Security=True;Encrypt=False;";
            return con; 
        }

        public double DailySales()
        {
            string sdate = DateTime.Now.ToShortDateString();
            using (SqlConnection cn = new SqlConnection(Myconnection()))
            {
                
                cn.Open();
                using (SqlCommand cm = new SqlCommand("SELECT isNull(sum(total),0) as total FROM tblCart WHERE sdate BETWEEN '" + sdate + "' and '" + sdate + "' and status like 'sold'", cn))
                {
                    dailysales =double.Parse(cm.ExecuteScalar().ToString());
                }
            }
           
            return dailysales;
        }

        public double ProductLine()
        {

            using (SqlConnection cn = new SqlConnection(Myconnection()))
            {

                cn.Open();
                using (SqlCommand cm = new SqlCommand("SELECT count(*) FROM tblProduct ", cn))
                {
                    productline = int.Parse(cm.ExecuteScalar().ToString());
                }
            }

            return productline;
        }

        public double StockOnHand()
        {

            using (SqlConnection cn = new SqlConnection(Myconnection()))
            {

                cn.Open();
                using (SqlCommand cm = new SqlCommand("SELECT isnull(sum(qty),0) as qty FROM tblProduct ", cn))
                {
                    stockonhand = int.Parse(cm.ExecuteScalar().ToString());
                }
            }

            return stockonhand;
        }
        public double CriticalItems()
        {

            using (SqlConnection cn = new SqlConnection(Myconnection()))
            {

                cn.Open();
                using (SqlCommand cm = new SqlCommand("SELECT count(*) FROM vwcriticalitems ", cn))
                {
                    critical = int.Parse(cm.ExecuteScalar().ToString());
                }
            }

            return critical;
        }
        public double GetVal()
        {

            //double vat = 0;
            //cn.ConnectionString=Myconnection();
            //cn.Open();
            //cm = new SqlCommand("SELECT * FROM tblVat", cn);
            //dr = cm.ExecuteReader();
            //while (dr.Read())
            //{
            //    {
            //        vat = double.Parse(dr[0].ToString());

            //    }
            //}
            //dr.Close();
            //cn.Close();
            //return vat;
            double vat = 0;
            using (SqlConnection cn = new SqlConnection(Myconnection()))
            {
                cn.Open();
                using (SqlCommand cm = new SqlCommand("SELECT * FROM tblVat", cn))
                using (SqlDataReader dr = cm.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        vat = double.Parse(dr[0].ToString());
                    }
                }
            }
            return vat;



        }

        public string GetPassword(string user)
        {
            string password="";
            using (SqlConnection cn = new SqlConnection(Myconnection()))
            {
                cn.Open();
                using (SqlCommand cm = new SqlCommand("SELECT * FROM tblUser WHERE username=@username", cn))
                    
                //dr.Read();
                //if (dr.HasRows())
                {
                    cm.Parameters.AddWithValue("username", user);
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            password = dr["password"].ToString();
                        }
                    }
                }
                
            }
            
            return password;
        }
    }
}
