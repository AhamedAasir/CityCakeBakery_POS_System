﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace demo
{
    public partial class frmVoid : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        frmCancelDetails f;
        public frmVoid(frmCancelDetails frm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.Myconnection());
            f = frm;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    if (txtPass.Text == string.Empty)
            //    {
            //        string user;
            //        cn.Open();
            //        cm = new SqlCommand("SELECT * FROM tblUser WHERE username = @username and password = @password", cn);
            //        cm.Parameters.AddWithValue("@username", txtUser.Text.Trim());
            //        cm.Parameters.AddWithValue("@password", txtPass.Text.Trim());
            //        dr = cm.ExecuteReader();
            //        dr.Read();
            //        if (dr.HasRows) 
            //        {

            //            user = dr["username"].ToString();
            //            dr.Close();
            //            cn.Close();

            //            SaveCancelOrder(user);
            //            if (f.cboAction.Text == "Yes")
            //            {
            //                UpdateDate("UPDATE tblProduct SET qty = qty + " + int.Parse(f.txtCancelQty.Text) + "WHERE pcode = '" + f.txtpCode.Text + "'");
            //            }

            //            UpdateDate("UPDATE tblCart SET qty = qty - " + int.Parse(f.txtCancelQty.Text) + " WHERE id like '" + f.txtID.Text + "'");

            //            MessageBox.Show("Order Transaction Successfully Cancelled!","Order Cancel",MessageBoxButtons.OK, MessageBoxIcon.Information);
            //            this.Dispose();
            //            f.RefreshList();
            //            f.Dispose();
            //        }
            //        else
            //        {
            //            dr.Close();
            //            cn.Close();
            //            MessageBox.Show("Invalid username or password", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //        }

            //    }
            //    else
            //    {
            //        MessageBox.Show("Please enter your password.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    }

            //}catch (Exception ex)
            //{
            //    cn.Close();
            //    MessageBox.Show(ex.Message,"Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning); return;
            //}
            try
            {
                if (string.IsNullOrWhiteSpace(txtPass.Text))
                {
                    MessageBox.Show("Please enter your password.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string user;
                cn.Open();
                cm = new SqlCommand("SELECT * FROM tblUser WHERE username = @username and password = @password", cn);
                cm.Parameters.AddWithValue("@username", txtUser.Text.Trim());
                cm.Parameters.AddWithValue("@password", txtPass.Text.Trim());
                dr = cm.ExecuteReader();
                dr.Read();

                if (dr.HasRows)
                {
                    user = dr["username"].ToString();
                    dr.Close();
                    cn.Close();

                    SaveCancelOrder(user);

                    if (f.cboAction.Text == "Yes")
                    {
                        UpdateDate("UPDATE tblProduct SET qty = qty + " + int.Parse(f.txtCancelQty.Text) + " WHERE pcode = '" + f.txtpCode.Text + "'");
                    }

                    UpdateDate("UPDATE tblCart SET qty = qty - " + int.Parse(f.txtCancelQty.Text) + " WHERE id = '" + f.txtID.Text + "'");

                    MessageBox.Show("Order Transaction Successfully Cancelled!", "Order Cancel", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Dispose();
                    f.RefreshList();
                    f.Dispose();
                }
                else
                {
                    MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        public void SaveCancelOrder(string user)
        {
            cn.Open();
            cm = new SqlCommand("INSERT INTO tblCancel (transno,pcode,price,qty,sdate,voidby,cancelledby,reason,action)VALUES(@transno,@pcode,@price,@qty,@sdate,@voidby,@cancelledby,@reason,@action)", cn);
            cm.Parameters.AddWithValue("@transno",f.txtTransNo.Text);
            cm.Parameters.AddWithValue("@pcode",f.txtpCode.Text);
            cm.Parameters.AddWithValue("@price",double.Parse(f.txtPrice.Text));
            cm.Parameters.AddWithValue("@qty",int.Parse(f.txtCancelQty.Text));
            cm.Parameters.AddWithValue("@sdate",DateTime.Now);
            cm.Parameters.AddWithValue("@voidby",user);
            cm.Parameters.AddWithValue("@cancelledby",f.txtCancel.Text);
            cm.Parameters.AddWithValue("@reason",f.txtReason.Text);
            cm.Parameters.AddWithValue("@action", f.cboAction.Text);
            cm.ExecuteNonQuery();
            cn.Close();
        }

        public void UpdateDate(string sql)
        {
            cn.Open();
            cm = new SqlCommand(sql,cn);
            cm.ExecuteNonQuery();
            cn.Close();
        }
    }
}
